<?php return array('dependencies' => array(), 'version' => '9c04187f1796859989c3');
