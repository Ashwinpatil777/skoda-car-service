<?php return array('dependencies' => array(), 'version' => '7500eb032759d407a71d');
