<?php return array('dependencies' => array(), 'version' => '2a0784014283afdd3c25');
