<?php return array('dependencies' => array('wp-react-refresh-runtime'), 'version' => '7f2b9b64306bff9c719f');
